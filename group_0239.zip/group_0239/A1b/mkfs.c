/*
 * This code is provided solely for the personal and private use of students
 * taking the CSC369H course at the University of Toronto. Copying for purposes
 * other than this use is expressly prohibited. All forms of distribution of
 * this code, including but not limited to public repositories on GitHub,
 * GitLab, Bitbucket, or any other online platform, whether as given or with
 * any changes, are expressly prohibited.
 *
 * Authors: Alexey Khrabrov, Karen Reid
 *
 * All of the files in this directory and all subdirectories are:
 * Copyright (c) 2019 Karen Reid
 */

/**
 * CSC369 Assignment 1 - a1fs formatting tool.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <math.h>
#include <time.h>

#include "a1fs.h"
#include "map.h"


/** Command line options. */
typedef struct mkfs_opts {
	/** File system image file path. */
	const char *img_path;
	/** Number of inodes. */
	size_t n_inodes;

	/** Print help and exit. */
	bool help;
	/** Overwrite existing file system. */
	bool force;
	/** Sync memory-mapped image file contents to disk. */
	bool sync;
	/** Verbose output. If false, the program must only print errors. */
	bool verbose;
	/** Zero out image contents. */
	bool zero;

} mkfs_opts;

static const char *help_str = "\
Usage: %s options image\n\
\n\
Format the image file into a1fs file system. The file must exist and\n\
its size must be a multiple of a1fs block size - %zu bytes.\n\
\n\
Options:\n\
    -i num  number of inodes; required argument\n\
    -h      print help and exit\n\
    -f      force format - overwrite existing a1fs file system\n\
    -s      sync image file contents to disk\n\
    -v      verbose output\n\
    -z      zero out image contents\n\
";

static void print_help(FILE *f, const char *progname)
{
	fprintf(f, help_str, progname, A1FS_BLOCK_SIZE);
}


static bool parse_args(int argc, char *argv[], mkfs_opts *opts)
{
	char o;
	while ((o = getopt(argc, argv, "i:hfsvz")) != -1) {
		switch (o) {
			case 'i': opts->n_inodes = strtoul(optarg, NULL, 10); break;

			case 'h': opts->help    = true; return true;// skip other arguments
			case 'f': opts->force   = true; break;
			case 's': opts->sync    = true; break;
			case 'v': opts->verbose = true; break;
			case 'z': opts->zero    = true; break;

			case '?': return false;
			default : assert(false);
		}
	}

	if (optind >= argc) {
		fprintf(stderr, "Missing image path\n");
		return false;
	}
	opts->img_path = argv[optind];

	if (opts->n_inodes == 0) {
		fprintf(stderr, "Missing or invalid number of inodes\n");
		return false;
	}
	return true;
}


/** Determine if the image has already been formatted into a1fs. */
static bool a1fs_is_present(void *image)
{
	//TODO: check if the image already contains a valid a1fs superblock
	struct a1fs_superblock *sb = (struct a1fs_superblock*)(image);
	if(sb->magic != A1FS_MAGIC){
		//(void)image;
		return false;
	}

	(void)image;
	return true;
}


/**
 * Format the image into a1fs.
 *
 * NOTE: Must update mtime of the root directory.
 *
 * @param image  pointer to the start of the image.
 * @param size   image size in bytes.
 * @param opts   command line options.
 * @return       true on success;
 *               false on error, e.g. options are invalid for given image size.
 */
static bool mkfs(void *image, size_t size, mkfs_opts *opts)
{
	//TODO: initialize the superblock and create an empty root directory

	int inodesinblock = A1FS_BLOCK_SIZE/A1FS_INODE_SIZE; //4096/64 = 64
	int numinodes = opts->n_inodes;
	int iblocksreserve = numinodes/inodesinblock; //number of reserved blocks for inodes
	if(numinodes % inodesinblock > 0) iblocksreserve++;
	size_t capacity = 3+iblocksreserve+1;

	int numdatablocks;
	if ((size/A1FS_BLOCK_SIZE)-(3+numinodes+iblocksreserve) < A1FS_BLOCK_SIZE*8){
		numdatablocks = (size/A1FS_BLOCK_SIZE)-(3+iblocksreserve);
	}
	else{
		numdatablocks = A1FS_BLOCK_SIZE*8;
	} // numdatablocks should be min of A1FS_BLOCK_SIZE*8 (max num of bits in the block bitmap) or dependent on size
	memset(image, 0, size);

	//size should at least be able to contain all bitmaps, inodes, extents, and some data
	if(numinodes > A1FS_BLOCK_SIZE*8){
		(void)image;
		(void)size;
		(void)opts;
		fprintf(stderr, "Too many inodes, shouldn't exceed 8*4096 inodes\n");
		return false;
	}
	if(size/A1FS_BLOCK_SIZE < capacity){
		(void)image;
		(void)size;
		(void)opts;
		fprintf(stderr, "Size too small, try giving your image more space\n");
		return false;
	}

	//initialize super block into first block
	struct a1fs_superblock *sb = (struct a1fs_superblock*)(image);	
	sb->magic = A1FS_MAGIC;
	sb->size = size;
	sb->num_inodes = numinodes; // number of total inodes
	sb->num_blocks = numdatablocks; // number of total blocks, max of 4096*8
	sb->free_blocks = numdatablocks; // number of free blocks
	sb->used_blocks = 0; // number of used blocks
	sb->free_inodes = numinodes; // number of free inodes
	sb->used_inodes = 0; // number of used inodes
	sb->blockbitmap = 1; // block num of block bitmap
	sb->firstinode = 3; // block num of first inode
	sb->inodebitmap = 2; // block num of inode bitmap
	sb->firstdatablock = sb->firstinode+iblocksreserve;
	//sb->firstextentblock = 3+iblocksreserve;
	sb->invalidinode = numinodes;

	//initialize block bitmap into second block
	char *blockmap = (char*)(image + A1FS_BLOCK_SIZE);
	char blockbm[numdatablocks];
	for (int i = 0; i < numdatablocks; i++){
		blockbm[i] = '0';
	}
	strcpy(blockmap, blockbm);

	//initialize inode bitmap into third block
	char *inodemap = (char*)(image + 2*A1FS_BLOCK_SIZE);
	char inodebm[numinodes];
	for (int i = 0; i < numinodes; i++){
		inodebm[i] = '0';
	}
	strcpy(inodemap, inodebm);

	//initialize inode table 
	int ext_count = 0;
	int iblock = 0;
	int ipadding = 0;
	for(int i = 0; i < numinodes; i++){
		struct a1fs_inode *ai = (struct a1fs_inode*)(image +(3+iblock)*A1FS_BLOCK_SIZE + ipadding*A1FS_INODE_SIZE);
		//ai->mode = NULL;
		ai->links = 0;
		ai->size = 0;
		clock_gettime(CLOCK_REALTIME, &(ai->mtime));
		ai->blocks_count = 0; // blocks used by the file including the block for its extents
		ai->inum = i;
		//ai->extents_block = 3+iblocksreserve+ext_count; // block number containing all 512 potential extent structs for the file, reserving extent block
		ai->extents_used = 0;
		ext_count++;
		ipadding++;
		if(ipadding == inodesinblock){
			iblock++;
			ipadding = 0;
		}
	}

	//make root dir
	struct a1fs_inode *rooti = (struct a1fs_inode*)(image + sb->firstinode*A1FS_BLOCK_SIZE); //find 1st inode which will be the root dir inode
	rooti->mode = S_IFDIR | 0777; //update root dirs inode data
	rooti->links = 2;
	rooti->size = A1FS_BLOCK_SIZE;
	clock_gettime(CLOCK_REALTIME, &(rooti->mtime));
	rooti->blocks_count = 1;
	//rooti inum already there = 0
	rooti->extents_used = 1;
	rooti->extents_block = sb->firstdatablock;

	struct a1fs_extent *rex = (struct a1fs_extent*)(image + rooti->extents_block*A1FS_BLOCK_SIZE); //make root dirs extent
	rex->count = 1; //update root dir extents data
	rex->start = sb->firstdatablock+1; // stored in the first data block
	
	struct a1fs_dentry *rdir = (struct a1fs_dentry*)(image + rex->start*A1FS_BLOCK_SIZE);
	strcpy(rdir->name, "/\0"); //set dir name with null char at end
	rdir->ino = 0; //set inode num
	struct a1fs_dentry *selfdir = (struct a1fs_dentry*)(image + rex->start*A1FS_BLOCK_SIZE+A1FS_DENTRY_SIZE);
	strcpy(selfdir->name, ".\0"); //set dir name with null char at end
	selfdir->ino = 0; //set inode num
	struct a1fs_dentry *parentdir = (struct a1fs_dentry*)(image + rex->start*A1FS_BLOCK_SIZE+2*A1FS_DENTRY_SIZE);
	strcpy(parentdir->name, "..\0"); //set dir name with null char at end
	parentdir->ino = sb->invalidinode; //set inode num

	inodemap[0] = '1'; //update inode bitmap
	blockmap[0] = '1'; //update data block bitmap
	blockmap[1] = '1';
	sb->free_blocks-=2; //update superblock data
	sb->free_inodes--;
	sb->used_blocks+=2;
	sb->used_inodes++;
	
	// (void)image;
	// (void)size;
	// (void)opts;
	return true;
}


int main(int argc, char *argv[])
{
	mkfs_opts opts = {0};// defaults are all 0
	if (!parse_args(argc, argv, &opts)) {
		// Invalid arguments, print help to stderr
		print_help(stderr, argv[0]);
		return 1;
	}
	if (opts.help) {
		// Help requested, print it to stdout
		print_help(stdout, argv[0]);
		return 0;
	}

	// Map image file into memory
	size_t size;
	void *image = map_file(opts.img_path, A1FS_BLOCK_SIZE, &size);
	if (image == NULL) return 1;

	// Check if overwriting existing file system
	int ret = 1;
	if (!opts.force && a1fs_is_present(image)) {
		fprintf(stderr, "Image already contains a1fs; use -f to overwrite\n");
		goto end;
	}

	if (opts.zero) memset(image, 0, size);
	if (!mkfs(image, size, &opts)) {
		fprintf(stderr, "Failed to format the image\n");
		goto end;
	}

	// Sync to disk if requested
	if (opts.sync && (msync(image, size, MS_SYNC) < 0)) {
		perror("msync");
		goto end;
	}

	ret = 0;
end:
	munmap(image, size);
	return ret;
}
