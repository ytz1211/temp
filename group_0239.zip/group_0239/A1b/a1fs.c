/*
 * This code is provided solely for the personal and private use of students
 * taking the CSC369H course at the University of Toronto. Copying for purposes
 * other than this use is expressly prohibited. All forms of distribution of
 * this code, including but not limited to public repositories on GitHub,
 * GitLab, Bitbucket, or any other online platform, whether as given or with
 * any changes, are expressly prohibited.
 *
 * Authors: Alexey Khrabrov, Karen Reid
 *
 * All of the files in this directory and all subdirectories are:
 * Copyright (c) 2019 Karen Reid
 */

/**
 * CSC369 Assignment 1 - a1fs driver implementation.
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/mman.h>

// Using 2.9.x FUSE API
#define FUSE_USE_VERSION 29
#include <fuse.h>

#include "a1fs.h"
#include "fs_ctx.h"
#include "options.h"
#include "map.h"

//NOTE: All path arguments are absolute paths within the a1fs file system and
// start with a '/' that corresponds to the a1fs root directory.
//
// For example, if a1fs is mounted at "~/my_csc369_repo/a1b/mnt/", the path to a
// file at "~/my_csc369_repo/a1b/mnt/dir/file" (as seen by the OS) will be
// passed to FUSE callbacks as "/dir/file".
//
// Paths to directories (except for the root directory - "/") do not end in a
// trailing '/'. For example, "~/my_csc369_repo/a1b/mnt/dir/" will be passed to
// FUSE callbacks as "/dir".


static void readFromImg(fs_ctx *fs){


}

static void writeToImg(fs_ctx *fs){

}


/**
 * Initialize the file system.
 *
 * Called when the file system is mounted. NOTE: we are not using the FUSE
 * init() callback since it doesn't support returning errors. This function must
 * be called explicitly before fuse_main().
 *
 * @param fs    file system context to initialize.
 * @param opts  command line options.
 * @return      true on success; false on failure.
 */
static bool a1fs_init(fs_ctx *fs, a1fs_opts *opts)
{
	// Nothing to initialize if only printing help or version
	if (opts->help || opts->version) return true;

	size_t size;
	void *image = map_file(opts->img_path, A1FS_BLOCK_SIZE, &size);
	if (!image) return false;

	return fs_ctx_init(fs, image, size, opts);
}

/**
 * Cleanup the file system.
 *
 * Called when the file system is unmounted. Must cleanup all the resources
 * created in a1fs_init().
 */
static void a1fs_destroy(void *ctx)
{
	fs_ctx *fs = (fs_ctx*)ctx;
	if (fs->image) {
		if (fs->opts->sync && (msync(fs->image, fs->size, MS_SYNC) < 0)) {
			perror("msync");
		}
		munmap(fs->image, fs->size);
		fs_ctx_destroy(fs);
	}
}

/** Get file system context. */
static fs_ctx *get_fs(void)
{
	return (fs_ctx*)fuse_get_context()->private_data;
}

// helper to find the inode of the dentry num of the proper entry
static int loop_extents_ad(fs_ctx *fs, a1fs_inode *ai, a1fs_extent *ei, a1fs_dentry *ad ,const char *filename){
	//loops through all extents used by ai
	uint64_t j;
	for(int i = 0; i<ai->extents_used; i++){
		ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE+i*8);
		j = 0; // j is the counter to help ad move onto the next dentry
		while(strcmp(ad->name, filename)!=0 && j < (A1FS_BLOCK_SIZE*ei->count)/A1FS_DENTRY_SIZE){ // iterate over all the dentries until we find filename
			ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + j*A1FS_DENTRY_SIZE);
			j++;
		}
		if(strcmp(ad->name, filename)==0) return (int)j-1; // return the dentry num if we find the proper entry
	}
	return -1;
}

// helper to find the inode of the proper entry in the dir
static int loop_extents(fs_ctx *fs, a1fs_inode *ai, a1fs_extent *ei, a1fs_dentry *ad ,const char *filename){
	//loops through all extents used by ai
	uint64_t j;
	for(int i = 0; i<ai->extents_used; i++){
		ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE+i*8);
		j = 0; // j is the counter to help ad move onto the next dentry
		while(strcmp(ad->name, filename)!=0 && j < (A1FS_BLOCK_SIZE*ei->count)/A1FS_DENTRY_SIZE){ // iterate over all the dentries until we find filename
			ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + j*A1FS_DENTRY_SIZE);
			j++;
		}
		if(strcmp(ad->name, filename)==0) return ad->ino; // return the inode num if we find the proper entry
	}
	return -1;
}

// helper to return the files inode number based on the path
static int path_to_inode(fs_ctx *fs, const char *path, a1fs_inode *ai){
	struct a1fs_superblock *sb = (struct a1fs_superblock*)(fs->image); // get superblock from fs
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
	struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE);

	if(strcmp(path, "/")==0){ // nothing to do for root path
		return 0;
	}
	
	// loop to get each filename and find its inode
	// for example: path is /abc/def/ghi
	char *pathfind = strchr(path, '/');
	char *filename = malloc(sizeof(char)*FILENAME_MAX);
	int i; 
    do{
        pathfind = strchr(pathfind, '/')+1; // skips over each '/' found by strchr, 1st iteration: abc/def/ghi
        i = 0; // i is the counter for number of chars until next '/'
		if(strchr(pathfind, '/')!=NULL){ // case for when we are not at the bottom file yet
		    while(pathfind[i] != '/'){
		        i++;
		    }
		    strncpy(filename, pathfind, i); // we use i to strncpy for number of chars to copy
		    filename[i+1]= '\0'; // eg. 1st iteration of do while loop has filename = abc
		}
		else{ // case for when we are at the bottom file, no more '/'
		    strcpy(filename, pathfind); //eg. last iteration of do while loop has filename = ghi
		}
		int key = loop_extents(fs, ai, ei, ad, filename);
		if(key==-1) return -1; // find file in ai's extents and update the data structs

		// update structs to match the directory on the current iteration
		ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + key*A1FS_INODE_SIZE);
		if(strchr(pathfind, '/') != NULL && (ai->mode != S_IFDIR)) return -2; // check if intermediate steps are dirs
		ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
		ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE);
		
    }while(strchr(pathfind, '/') != NULL); // go to name of file in the path
	free(filename);

	return ai->inum; // return the inodes number so we can easily find it in the parent func
}

/**
 * Get file system statistics.
 *
 * Implements the statvfs() system call. See "man 2 statvfs" for details.
 * The f_bfree and f_bavail fields should be set to the same value.
 * The f_ffree and f_favail fields should be set to the same value.
 * The following fields can be ignored: f_fsid, f_flag.
 * All remaining fields are required.
 *
 * @param path  path to any file in the file system. Can be ignored.
 * @param st    pointer to the struct statvfs that receives the result.
 * @return      0 on success; -errno on error.
 */
static int a1fs_statfs(const char *path, struct statvfs *st)
{
	(void)path;// unused
	fs_ctx *fs = get_fs();
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);	
	memset(st, 0, sizeof(*st));
	st->f_bsize   = A1FS_BLOCK_SIZE;
	st->f_frsize  = A1FS_BLOCK_SIZE;
	//TODO: fill in the rest of required fields based on the information stored
	// in the superblock
	st->f_blocks = sb->size/A1FS_BLOCK_SIZE;
	st->f_bfree = sb->free_blocks;
	st->f_bavail = sb->free_blocks;
	st->f_files = sb->num_inodes;
	st->f_ffree = sb->free_inodes;
	st->f_favail = sb->free_inodes;

	(void)fs;
	st->f_namemax = A1FS_NAME_MAX;

	return 0;
}

/**
 * Get file or directory attributes.
 *
 * Implements the stat() system call. See "man 2 stat" for details.
 * The following fields can be ignored: st_dev, st_ino, st_uid, st_gid, st_rdev,
 *                                      st_blksize, st_atim, st_ctim.
 * All remaining fields are required.
 *
 * NOTE: the st_blocks field is measured in 512-byte units (disk sectors).
 *
 * Errors:
 *   ENAMETOOLONG  the path or one of its components is too long.
 *   ENOENT        a component of the path does not exist.
 *   ENOTDIR       a component of the path prefix is not a directory.
 *
 * @param path  path to a file or directory.
 * @param st    pointer to the struct stat that receives the result.
 * @return      0 on success; -errno on error;
 */
static int a1fs_getattr(const char *path, struct stat *st)
{
	if (strlen(path) >= A1FS_PATH_MAX) return -ENAMETOOLONG;
	fs_ctx *fs = get_fs();
	struct a1fs_superblock *sb = (struct a1fs_superblock*)(fs->image); // get superblock from fs
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	memset(st, 0, sizeof(*st));

	st->st_mode = ai->mode; // basic case for root dir
	st->st_nlink = ai->links;
	st->st_size = ai->size;
	st->st_blocks = ai->blocks_count/8;
	if(ai->blocks_count%8>0)st->st_blocks++;
	st->st_mtim = ai->mtime;

	//TODO: lookup the inode for given path and, if it exists, fill in the
	// required fields based on the information stored in the inode
	int ainum = path_to_inode(fs, path, ai);
	if(ainum>=0){ // update st with found files inode info
		ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE);
		st->st_mode = ai->mode;
		st->st_nlink = ai->links;
		st->st_size = ai->size;
		st->st_blocks = ai->blocks_count/8;
		if(ai->blocks_count%8>0)st->st_blocks++;
		st->st_mtim = ai->mtime;
		return 0;
	}
	else if (ainum==-1){ // case where files inode not found
		return -ENOENT;
	}
	else if(ainum==-2){ // case where somewhere middle in the path is not a dir
		return -ENOTDIR;
	}

	return 0;
}

/**
 * Read a directory.
 *
 * Implements the readdir() system call. Should call filler() for each directory
 * entry. See fuse.h in libfuse source code for details.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists and is a directory.
 *
 * Errors:
 *   ENOMEM  not enough memory (e.g. a filler() call failed).
 *
 * @param path    path to the directory.
 * @param buf     buffer that receives the result.
 * @param filler  function that needs to be called for each directory entry.
 *                Pass 0 as offset (4th argument). 3rd argument can be NULL.
 * @param offset  unused.
 * @param fi      unused.
 * @return        0 on success; -errno on error.
 */
static int a1fs_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                        off_t offset, struct fuse_file_info *fi)
{
	(void)offset;// unused
	(void)fi;// unused
	fs_ctx *fs = get_fs();
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);

	//NOTE: This is just a placeholder that allows the file system to be mounted
	// without errors. You should remove this from your implementation.
	if (strcmp(path, "/") == 0) {
		for(uint64_t i = 1; i<ai->links+1;i++){
			struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + i*sizeof(struct a1fs_dentry));
			filler(buf, ad->name , NULL, 0);
		}
		return 0;
	}

	//TODO: lookup the directory inode for given path and iterate through its
	// directory entries
	int ainum = path_to_inode(fs, path, ai);
	if(ainum>=0){
		ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE);
		ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
		for(uint64_t i = 1; i<ai->links+1;i++){
			struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + i*sizeof(struct a1fs_dentry));
			if(ad->ino != sb->invalidinode){
				filler(buf, ad->name , NULL, 0);
			}
		}
		return 0;
	}

	(void)fs;
	return -ENOSYS;
}

// helper to find an empty inode
uint64_t find_empty_inode(fs_ctx *fs, struct a1fs_superblock *sb) { 
	char *inodemap = (char*)(fs->image + sb->inodebitmap*A1FS_BLOCK_SIZE);
	uint64_t i = 0;
	while (inodemap[i] == '1' && i<sb->num_inodes) // find i = first empty inode
		i++;
	return i;
}

// helper to find an empty block
uint64_t find_empty_block(fs_ctx *fs, struct a1fs_superblock *sb) { 
	char *blockmap = (char*)(fs->image + A1FS_BLOCK_SIZE);
	uint64_t b = 0;
	while (blockmap[b] == '1' && b<sb->num_blocks) // find b = first empty block
		b++;
	return b;
}

// helper of for getting parent path of a file
int get_parent_path(char *result, const char *path) { 
	char parentpath[A1FS_PATH_MAX];
	int j = 0; // counter for last '/'
    int lastfile;
    while(path[j]!='\0'){
        if(path[j]=='/'){
            lastfile = j;
        }
        j++;
    }
    strncpy(parentpath, path, lastfile);
    parentpath[lastfile+1] = '\0';
    strcpy(result, parentpath);
    return 0;
}

 // helper for getting file name
int get_file_name(char *result, const char *path) {
	char *filename = strchr(path, '/');
	while(strchr(filename, '/')!=NULL){ 
		filename = strchr(filename, '/')+1;
	}  
	strcpy(result, filename);
	return 0;
}

// updates the superblock and block map when new block is used
void blockmap_update(uint64_t b, fs_ctx *fs){ 
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	char *blockmap = (char*)(fs->image+sb->blockbitmap*A1FS_BLOCK_SIZE);
	blockmap[b] = '1';
	sb->free_blocks--;
	sb->used_blocks++;
}

 // add extra space in dir to allow more dentrys to be stored
int extend_size(fs_ctx *fs, a1fs_inode *ai){
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	uint64_t b = find_empty_block(fs, sb); // get the latest empty block
	if(b>= sb->num_blocks){
		return -1; // no more space
	}
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE + ai->extents_used*8);
	ei->start = sb->firstdatablock+b;
	ei->count = 1;
	// update ai data
	ai->extents_used++;
	ai->blocks_count++;
	ai->size += A1FS_BLOCK_SIZE;
	blockmap_update(b, fs);
	return 0;
}

// helper to add filenames entry to its parent dir
int	add_to_parent(fs_ctx *fs, a1fs_inode *ai, char *parentpath, char *filename, uint64_t i) {
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);

	// finds parent dir of filename and add its entry to the parent
	int ainum = path_to_inode(fs, parentpath, ai);
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE); // get the new inode of the parent dir

	int j = ai->links+1 % (A1FS_BLOCK_SIZE/A1FS_DENTRY_SIZE);
	if(j==0){ // if no space left we add another block
		if(extend_size(fs, ai)!=0) return -1;
	}
	ai->links++;
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image+ai->extents_block*A1FS_BLOCK_SIZE+(ai->extents_used-1)*8); //seaches through the current ext being used
	struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + j*A1FS_DENTRY_SIZE);
	ad->ino = i;
	strcpy(ad->name, filename); 	
	return 0;
}


/**
 * Create a directory.
 *
 * Implements the mkdir() system call.
 *
 * NOTE: the mode argument may not have the type specification bits set, i.e.
 * S_ISDIR(mode) can be false. To obtain the correct directory type bits use
 * "mode | S_IFDIR".
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" doesn't exist.
 *   The parent directory of "path" exists and is a directory.
 *   "path" and its components are not too long.
 *
 * Errors:
 *   ENOMEM  not enough memory (e.g. a malloc() call failed).
 *   ENOSPC  not enough free space in the file system.
 *
 * @param path  path to the directory to create.
 * @param mode  file mode bits.
 * @return      0 on success; -errno on error.
 */
static int a1fs_mkdir(const char *path, mode_t mode)
{
	if(strlen(path+1) >= A1FS_NAME_MAX || strlen(path) >= A1FS_PATH_MAX) return ENAMETOOLONG;
	fs_ctx *fs = get_fs();

	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	char *inodemap = (char*)(fs->image+sb->inodebitmap*A1FS_BLOCK_SIZE);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	uint64_t i = find_empty_inode(fs, sb);
	if(i >= sb->num_inodes) return -ENOSPC; // no more space

	char *parentpath = malloc(sizeof(char)*A1FS_PATH_MAX); //init parent dir path
	if (parentpath == NULL) return -ENOMEM;
	strcpy(parentpath, path);
	parentpath[1] = '\0';

	char *filename = malloc(A1FS_NAME_MAX*sizeof(char)); // init file name
	if (parentpath == NULL) return -ENOMEM;
	strncpy(filename, path+1, strlen(path+1));
	filename[strlen(path+1)] = '\0';

	// adds entry of filename to parent dir
	if(add_to_parent(fs, ai, parentpath, filename, i)!=0) return -ENOSPC; // only reason it fails should be not enough space

	uint64_t b = find_empty_block(fs, sb);
	if(i >= sb->num_inodes || b>= sb->num_blocks) return -ENOSPC; // no more space
	blockmap_update(b, fs); // for newdiri extents_block

	// init new inode for the new dir
	struct a1fs_inode *newdiri = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + i*A1FS_INODE_SIZE);
	newdiri->mode = S_IFDIR | 0777;; //update new dirs inode data
	newdiri->links = 2;
	newdiri->size = A1FS_BLOCK_SIZE;
	clock_gettime(CLOCK_REALTIME, &(newdiri->mtime));
	newdiri->blocks_count = 1;
	//newdiri inum already there = i
	newdiri->extents_used = 1;
	newdiri->extents_block = sb->firstdatablock + b;

	b = find_empty_block(fs, sb);
	if(i >= sb->num_inodes || b>= sb->num_blocks) return -ENOSPC; // no more space
	blockmap_update(b, fs); // for newdex start

	struct a1fs_extent *newdex = (struct a1fs_extent*)(fs->image + newdiri->extents_block*A1FS_BLOCK_SIZE); //make new dirs extent
	newdex->count = 1; //update new dir extents data
	newdex->start = sb->firstdatablock+b; // stored in the first data block

	struct a1fs_dentry *newdir = (struct a1fs_dentry*)(fs->image + newdex->start*A1FS_BLOCK_SIZE);
	strcpy(newdir->name, filename); //set dir name with null char at end
	newdir->ino = newdiri->inum; //set inode num
	struct a1fs_dentry *selfdir = (struct a1fs_dentry*)(fs->image + newdex->start*A1FS_BLOCK_SIZE+A1FS_DENTRY_SIZE);
	strcpy(selfdir->name, ".\0"); //set dir name with null char at end
	selfdir->ino = newdiri->inum; //set inode num
	struct a1fs_dentry *parentdir = (struct a1fs_dentry*)(fs->image + newdex->start*A1FS_BLOCK_SIZE+2*A1FS_DENTRY_SIZE);
	strcpy(parentdir->name, "..\0"); //set dir name with null char at end
	parentdir->ino = ai->inum; //set inode num

	inodemap[i] = '1'; //update inode bitmap
	sb->free_inodes--;
	sb->used_inodes++;

	free(parentpath);
	free(filename);
	printf("%d", mode);
	return 0;
}

/**
 * Remove a directory.
 *
 * Implements the rmdir() system call.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists and is a directory.
 *
 * Errors:
 *   ENOTEMPTY  the directory is not empty.
 *
 * @param path  path to the directory to remove.
 * @return      0 on success; -errno on error.
 */
static int a1fs_rmdir(const char *path)
{
	fs_ctx *fs = get_fs();

	char *parentpath = malloc(sizeof(char)*A1FS_PATH_MAX); //init parent dir path
	if (parentpath == NULL) return -ENOMEM;
	strcpy(parentpath, path);
	parentpath[1] = '\0';

	char *filename = malloc(A1FS_NAME_MAX*sizeof(char)); // init file name
	if (parentpath == NULL) return -ENOMEM;
	strncpy(filename, path+1, strlen(path+1));
	filename[strlen(path+1)] = '\0';

	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);

	// only one extent block from assumption of empty directory 
	int ainum = path_to_inode(fs, path, ai);
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE); //get inode of dir to be removed
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
	if(ai->links>=3) return -ENOTEMPTY;

	// reset 1 to 0 in block bitmap
	int blocksremoved = 1;
	char *blockmap = (char*)(fs->image + sb->blockbitmap*A1FS_BLOCK_SIZE); // update to support rm the multiple blocks in an extent
	blockmap[ei->start - sb->firstdatablock] = '0'; // the data block used by the extent in the extent block

	// reset 1 to 0 in inode bitmap
	char *inodemap = (char*)(fs->image + sb->inodebitmap*A1FS_BLOCK_SIZE);
	inodemap[ai->inum] = '0';	

	sb->free_blocks+=blocksremoved; //update superblock data
	sb->free_inodes++;
	sb->used_blocks-=blocksremoved;
	sb->used_inodes--;

	//update parent info
	ainum = path_to_inode(fs, parentpath, ai);
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE);
	ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
	struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE);

	int key = loop_extents_ad(fs, ai, ei, ad, filename);
	if(key==-1) return -ENODATA; // find file in parent ai's extents and update the data structs
	ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + key*A1FS_DENTRY_SIZE);

	ad->ino = sb->invalidinode; // update parent dentry for the removed dir
	ai->links--;

	free(parentpath);
	free(filename);
	return 0;
}

/**
 * Create a file.
 *
 * Implements the open()/creat() system call.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" doesn't exist.
 *   The parent directory of "path" exists and is a directory.
 *   "path" and its components are not too long.
 *
 * Errors:
 *   ENOMEM  not enough memory (e.g. a malloc() call failed).
 *   ENOSPC  not enough free space in the file system.
 *
 * @param path  path to the file to create.
 * @param mode  file mode bits.
 * @param fi    unused.
 * @return      0 on success; -errno on error.
 */
static int a1fs_create(const char *path, mode_t mode, struct fuse_file_info *fi)
{
	(void)fi;// unused
	assert(S_ISREG(mode));
	if(strlen(path+1) >= A1FS_NAME_MAX || strlen(path) >= A1FS_PATH_MAX) return ENAMETOOLONG;
	fs_ctx *fs = get_fs();

	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	char *inodemap = (char*)(fs->image+sb->inodebitmap*A1FS_BLOCK_SIZE);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	uint64_t i = find_empty_inode(fs, sb);
	if(i >= sb->num_inodes) return -ENOSPC; // no more space

	char *parentpath = malloc(sizeof(char)*A1FS_PATH_MAX); //init parent dir path
	if (parentpath == NULL) return -ENOMEM;
	strcpy(parentpath, path);
	parentpath[1] = '\0';

	char *filename = malloc(A1FS_NAME_MAX*sizeof(char)); // init file name
	if (parentpath == NULL) return -ENOMEM;
	strncpy(filename, path+1, strlen(path+1));
	filename[strlen(path+1)] = '\0';

	// adds entry of filename to parent dir
	if(add_to_parent(fs, ai, parentpath, filename, i)!=0) return -ENOSPC; // only reason it fails should be not enough space

	uint64_t b = find_empty_block(fs, sb);
	if(i >= sb->num_inodes || b>= sb->num_blocks) return -ENOSPC; // no more space
	blockmap_update(b, fs); // for newfilei extents_block

	// create new inode
	struct a1fs_inode *newfilei = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + i*A1FS_INODE_SIZE);
	newfilei->mode = mode; //update new file inode data
	newfilei->links = 2;
	newfilei->size = A1FS_BLOCK_SIZE;
	clock_gettime(CLOCK_REALTIME, &(newfilei->mtime));
	newfilei->blocks_count = 1;
	//newfilei inum already there = i
	newfilei->extents_used = 1;
	newfilei->extents_block = sb->firstdatablock + b; // needs block map to be updated

	b = find_empty_block(fs, sb);
	if(i >= sb->num_inodes || b>= sb->num_blocks){
		return -ENOSPC; // no more space
	}
	blockmap_update(b, fs); // for newfex start
	// create new extent
	struct a1fs_extent *newfex = (struct a1fs_extent*)(fs->image + newfilei->extents_block*A1FS_BLOCK_SIZE); //make new files extent
	newfex->count = 1; //update new files extents data
	newfex->start = sb->firstdatablock+b; // stored in the first data block + first free block, needs block map to be updated
	
	// create new dentry
	struct a1fs_dentry *newdir = (struct a1fs_dentry*)(fs->image + newfex->start*A1FS_BLOCK_SIZE);
	strcpy(newdir->name, filename); //set file name with null char at end
	newdir->ino = newfilei->inum; //set inode num

	inodemap[i] = '1'; //update inode bitmap
	sb->free_inodes--;
	sb->used_inodes++;

	free(parentpath);
	free(filename);

	return 0;
}

/**
 * Remove a file.
 *
 * Implements the unlink() system call.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists and is a file.
 *
 * @param path  path to the file to remove.
 * @return      0 on success; -errno on error.
 */
static int a1fs_unlink(const char *path)
{
	fs_ctx *fs = get_fs();

	char *parentpath = malloc(sizeof(char)*A1FS_PATH_MAX); //init parent dir path
	if (parentpath == NULL) return -ENOMEM;
	strcpy(parentpath, path);
	parentpath[1] = '\0';

	char *filename = malloc(A1FS_NAME_MAX*sizeof(char)); // init file name
	if (parentpath == NULL) return -ENOMEM;
	strncpy(filename, path+1, strlen(path+1));
	filename[strlen(path+1)] = '\0';

	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
	//update parent info
	int ainum = path_to_inode(fs, parentpath, ai);
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE);
	ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
	struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE);

	int key = loop_extents_ad(fs, ai, ei, ad, filename); // get the right 
	if(key==-1) return -ENODATA; // find file in parent ai's extents and update the data structs
	ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE + key*A1FS_DENTRY_SIZE);

	ad->ino = sb->invalidinode; // update parent dentry for the removed dir
	ai->links--;

	free(parentpath);
	free(filename);

	return 0;
}

/**
 * Rename a file or directory.
 *
 * Implements the rename() system call. See "man 2 rename" for details.
 * If the destination file (directory) already exists, it must be replaced with
 * the source file (directory). Existing destination can be replaced if it's a
 * file or an empty directory.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "from" exists.
 *   The parent directory of "to" exists and is a directory.
 *   If "from" is a file and "to" exists, then "to" is also a file.
 *   If "from" is a directory and "to" exists, then "to" is also a directory.
 *
 * Errors:
 *   ENOMEM     not enough memory (e.g. a malloc() call failed).
 *   ENOTEMPTY  destination is a non-empty directory.
 *   ENOSPC     not enough free space in the file system.
 *
 * @param from  original file path.
 * @param to    new file path.
 * @return      0 on success; -errno on error.
 */
static int a1fs_rename(const char *from, const char *to)
{
	fs_ctx *fs = get_fs();
	// get parent path
	char *parentpath = malloc(sizeof(char)*A1FS_PATH_MAX); // get parent path (the path without the name of the new dir)
	get_parent_path(parentpath, from);

	// get name of file to be removed
	char *filename = malloc(sizeof(char)*A1FS_PATH_MAX);
	get_file_name(filename, from);

	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	path_to_inode(fs, parentpath, ai);
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE);
	struct a1fs_dentry *ad = (struct a1fs_dentry*)(fs->image + ei->start*A1FS_BLOCK_SIZE);
	loop_extents(fs,ai,ei,ad,filename);
	ad->ino = sb->invalidinode;
	ai->links--;

	// parentpath will be path without the name of the new dir
	get_parent_path(parentpath, to);
	get_file_name(filename, to);
	path_to_inode(fs, parentpath, ai);

	add_to_parent(fs, ai, parentpath, filename, ai->inum);

	free(parentpath);
	free(filename);

	//TODO: move the inode (file or directory) at given source path to the
	// destination path, according to the description above
	(void)from;
	(void)to;
	(void)fs;
	return -ENOSYS;
}


/**
 * Change the access and modification times of a file or directory.
 *
 * Implements the utimensat() system call. See "man 2 utimensat" for details.
 *
 * NOTE: You only have to implement the setting of modification time (mtime).
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists.
 *
 * @param path  path to the file or directory.
 * @param tv    timestamps array. See "man 2 utimensat" for details.
 * @return      0 on success; -errno on failure.
 */
static int a1fs_utimens(const char *path, const struct timespec tv[2])
{
	fs_ctx *fs = get_fs();

	//TODO: update the modification timestamp (mtime) in the inode for given
	// path with either the time passed as argument or the current time,
	// according to the utimensat man page

	struct a1fs_superblock *sb = (struct a1fs_superblock*)(fs->image); // get superblock from fs
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE); 

	int ainum = path_to_inode(fs, path, ai);
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE); // get inode of file to be updated
	// note: tv[0] = "last access time";	tv[1] = "last modification time" (use tv[1] only)	
	if (tv == NULL)
		clock_gettime(CLOCK_REALTIME, &(ai->mtime));
	else
		ai->mtime = tv[1];
	return 0;
}

/**
 * Change the size of a file.
 *
 * Implements the truncate() system call. Supports both extending and shrinking.
 * If the file is extended, future reads from the new uninitialized range must
 * return ranges filled with zeros.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists and is a file.
 *
 * Errors:
 *   ENOMEM  not enough memory (e.g. a malloc() call failed).
 *   ENOSPC  not enough free space in the file system.
 *
 * @param path  path to the file to set the size.
 * @param size  new file size in bytes.
 * @return      0 on success; -errno on error.
 */
static int a1fs_truncate(const char *path, off_t size)
{
	fs_ctx *fs = get_fs();
	struct a1fs_superblock *sb = (struct a1fs_superblock*)(fs->image); // get superblock from fs
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	int ainum = path_to_inode(fs, path, ai);
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE); // init inode for file
	
	size_t newsize = (ceil(size/A1FS_BLOCK_SIZE))*A1FS_BLOCK_SIZE; // set size in terms of block usage
	int diff; // block count difference between newsize and file size
	char *bbm = (char*)(fs->image + sb->blockbitmap*A1FS_BLOCK_SIZE); // data bitmap to be updated later

	if(newsize > ai->size){ // case for extending file size
		diff = (newsize - ai->size)/A1FS_BLOCK_SIZE;
		uint64_t start;
		while(diff>0){
			struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE + ai->extents_used*8);
			uint64_t b = find_empty_block(fs, sb); // find first empty block
			if(b>= sb->num_blocks){
				return -ENOSPC; // no more space
			}
			start = b;
			while(bbm[b]!='1' && b<sb->num_blocks && diff>0){ // find area of memory to add more space to file
				blockmap_update(b, fs);
				b++;
				diff--;
			}
			ai->extents_used++; // add new extent and init its data
			ei->start = start;
			ei->count = b-start;
		}
	}
	else if (newsize < ai->size){ // case for shortening file size
		diff = (ai->size - newsize)/A1FS_BLOCK_SIZE;
		while(diff>0){
			struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE + ai->extents_used*8);
			while(diff>0 && ei->count>0){ //loop through diff freeing blocks if they are not needed
				blockmap_update(ei->start + ei->count, fs);
				diff--;
				ei->count--;
			}
			if(ei->count == 0){ // free up extent if it is no longer needed
				ai->extents_used--;
			}
		}
	}
	ai->size = newsize; //update file size

	return 0;
}


/**
 * Read data from a file.
 *
 * Implements the pread() system call. Should return exactly the number of bytes
 * requested except on EOF (end of file) or error, otherwise the rest of the
 * data will be substituted with zeros. Reads from file ranges that have not
 * been written to must return ranges filled with zeros.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists and is a file.
 *
 * @param path    path to the file to read from.
 * @param buf     pointer to the buffer that receives the data.
 * @param size    buffer size (number of bytes requested).
 * @param offset  offset from the beginning of the file to read from.
 * @param fi      unused.
 * @return        number of bytes read on success; 0 if offset is beyond EOF;
 *                -errno on error.
 */
static int a1fs_read(const char *path, char *buf, size_t size, off_t offset,
                     struct fuse_file_info *fi)
{
	(void)fi;// unused
	fs_ctx *fs = get_fs();

	//TODO: read data from the file at given offset into the buffer
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);

	int ainum = path_to_inode(fs, path, ai);

	if (ainum==-1){
		return -ENOENT;
	}
	else if(ainum==-2){
		return -ENOTDIR;
	}
	// the lines below only run when ainum>=0
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE);

	// ai == inode of file
	if (ai->size <= (uint64_t) offset) { // offset is beyond EOF
		memset(buf, '0', size); 
		return 0;
	}
	else { // offset is not beyond EOF
		struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE); 
		// TODO: update to support multi extents: right now ei = first extent of file's extent block

		void *file_start = fs->image + ei->start*A1FS_BLOCK_SIZE + A1FS_DENTRY_SIZE + offset; 
		// pointer to start of file content + offset

		int amount_copied = (ai->size - offset > size ) ? ai->size - offset : size;
		memmove(buf, file_start, amount_copied); // copy file content into buf

		if (size < ai->size) { // fill remaining of buf to '0'
			char *tmp = "";
			memset(tmp, '0', ai->size - size);
			strcat(buf, tmp);
		}
		return size;
	}
}

/**
 * Write data to a file.
 *
 * Implements the pwrite() system call. Should return exactly the number of
 * bytes requested except on error. If the offset is beyond EOF (end of file),
 * the file must be extended. If the write creates a "hole" of uninitialized
 * data, future reads from the "hole" must return ranges filled with zeros.
 *
 * Assumptions (already verified by FUSE using getattr() calls):
 *   "path" exists and is a file.
 *
 * @param path    path to the file to write to.
 * @param buf     pointer to the buffer containing the data.
 * @param size    buffer size (number of bytes requested).
 * @param offset  offset from the beginning of the file to write to.
 * @param fi      unused.
 * @return        number of bytes written on success; -errno on error.
 */
static int a1fs_write(const char *path, const char *buf, size_t size,
                      off_t offset, struct fuse_file_info *fi)
{
	(void)fi;// unused
	fs_ctx *fs = get_fs();

	//TODO: write data from the buffer into the file at given offset, possibly
	// "zeroing out" the uninitialized range
	struct a1fs_superblock *sb = (struct a1fs_superblock *)(fs->image);
	struct a1fs_inode *ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE);
	
	int ainum = path_to_inode(fs, path, ai);

	if (ainum==-1){
		return -ENOENT;
	}
	else if(ainum==-2){
		return -ENOTDIR;
	}
	// the lines below only run when ainum>=0
	ai = (struct a1fs_inode*)(fs->image + sb->firstinode*A1FS_BLOCK_SIZE + ainum*A1FS_INODE_SIZE);

	// ai == inode of file
	struct a1fs_extent *ei = (struct a1fs_extent*)(fs->image + ai->extents_block*A1FS_BLOCK_SIZE); 
	// TODO: update to support multi extents: right now ei = first extent of file's extent block

	if (ai->size <= (uint64_t) offset) { // offset is beyond EOF
		void *orig_file_end = fs->image + ei->start*A1FS_BLOCK_SIZE + A1FS_DENTRY_SIZE + ai->size; 
		memset(orig_file_end, '0', (uint64_t)offset - ai->size);	// fill "hole" with 0's
		void *new_file_start = fs->image + ei->start*A1FS_BLOCK_SIZE + A1FS_DENTRY_SIZE + offset;
		memmove(new_file_start, buf, size); 						// write to file
		ai->size += (uint64_t)offset - ai->size + size;
	} 
	else { // offset is not beyond EOF
		void *new_file_start = fs->image + ei->start*A1FS_BLOCK_SIZE + A1FS_DENTRY_SIZE + offset;
		memmove(new_file_start, buf, size); 						// write to file
		if (ai->size < size + offset) 
			ai->size += size - (ai->size - (uint64_t)offset); // else ai->size does not change
	}
	return size;
	// (void)path;
	// (void)buf;
	// (void)size;
	// (void)offset;
	// (void)fs;
	// return -ENOSYS;
}


static struct fuse_operations a1fs_ops = {
	.destroy  = a1fs_destroy,
	.statfs   = a1fs_statfs,
	.getattr  = a1fs_getattr,
	.readdir  = a1fs_readdir,
	.mkdir    = a1fs_mkdir,
	.rmdir    = a1fs_rmdir,
	.create   = a1fs_create,
	.unlink   = a1fs_unlink,
	.rename   = a1fs_rename,
	.utimens  = a1fs_utimens,
	.truncate = a1fs_truncate,
	.read     = a1fs_read,
	.write    = a1fs_write,
};

int main(int argc, char *argv[])
{
	a1fs_opts opts = {0};// defaults are all 0
	struct fuse_args args = FUSE_ARGS_INIT(argc, argv);
	if (!a1fs_opt_parse(&args, &opts)) return 1;

	fs_ctx fs = {0};
	if (!a1fs_init(&fs, &opts)) {
		fprintf(stderr, "Failed to mount the file system\n");
		return 1;
	}

	return fuse_main(args.argc, args.argv, &a1fs_ops, &fs);
}
