﻿A1fs README
* If an operation does not work, the user needs to add sudo before the command.
* When testing, we had to change the for loop indexing for a1fs_readdir from 0 to 1 because of a problem of FUSE.


Functionality
1. getattr, readdir, statfs, utimens work fine
2. mkdir, rmdir, create, unlink, work within the root dir
3. read, write, truncate generally do not work
4. rename doesn't work

mostly tested on an image of size 409600 bytes and 64 inodes
